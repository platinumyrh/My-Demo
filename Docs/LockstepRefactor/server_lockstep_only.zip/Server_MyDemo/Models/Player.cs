using System;
using System.Net;

namespace Server_MyDemo.Models
{
    /// <summary>
    /// 已认证在线连接：只保留网络端点与心跳时间。
    /// lockstep 模式下服务器不持有玩家位置/血量等游戏状态。
    /// </summary>
    public class Player
    {
        public string PlayerId { get; set; } = string.Empty;
        public string PlayerName { get; set; } = "Player";

        public IPEndPoint? Endpoint { get; set; }
        public string IpAddress => Endpoint?.Address.ToString() ?? string.Empty;
        public int Port => Endpoint?.Port ?? 0;

        public bool IsOnline { get; set; } = true;
        public DateTime LastHeartbeatTime { get; set; } = DateTime.Now;

        public string GetUniqueKey() => $"{IpAddress}:{Port}";

        public void Touch()
        {
            LastHeartbeatTime = DateTime.Now;
            IsOnline = true;
        }

        public bool IsTimedOut(TimeSpan timeout) => DateTime.Now - LastHeartbeatTime > timeout;
    }
}
